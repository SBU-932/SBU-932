package main;

import game.Engine;
import window.Frame;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Frame f = new Frame();
		Engine eng = new Engine();
		eng.Maingame();
	}

}
